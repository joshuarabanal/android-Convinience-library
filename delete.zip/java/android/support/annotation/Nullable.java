/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package android.support.annotation;
import java.lang.annotation.*;

/**
 * this annotation allows the following field to be defined as null without errors being thrown
 * @author Joshua
 */
@Documented
public @interface Nullable{

}
